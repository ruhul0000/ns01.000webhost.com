<?php
if (!defined('IN_ADMIN')) die("Hacking attempt");


?>

     <!-- Main Footer -->

      <footer class="main-footer">

        <!-- To the right -->

        <div class="pull-right hidden-xs">

          Your Version <?php echo VERSION; ?>

        </div>

        <!-- Default to the left -->

        <strong>Copyright &copy; 2016 <a href="http://smallseostats.com/">SmallSeoStats.Com</a></strong> All rights reserved.

      </footer>


    </div>





    <script src="assets/plugins/jQuery/jQuery-2.1.4.min.js"></script>

    <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>

    <script src="assets/dist/js/app.min.js" type="text/javascript"></script>



    <script src="https://cdn.ckeditor.com/4.4.3/standard/ckeditor.js"></script>

  </body>

</html>