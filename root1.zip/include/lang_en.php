<?php

 

$lang = array();

 

$lang['1'] = "Home";

$lang['2'] = "Recent Website";

$lang['3'] = "Recent";

$lang['4'] = "Contact Us";

$lang['5'] = "My History";

$lang['6'] = "History";

$lang['7'] = "More";

$lang['8'] = "Enter a site";

$lang['9'] = "SEO Stats and Site Analysis";

$lang['10'] = "We Provide Ultimate SEO Analysis and Optimization Advice.";

$lang['11'] = "By clicking 'Check Up!' I agree to the 'Terms of Service'";

$lang['12'] = "SEO Stats Tool";

$lang['13'] = "SEO Stats";

$lang['14'] = "Traffic Stats";

$lang['15'] = "Geo Location";

$lang['16'] = "Site Info";

$lang['17'] = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever ...";

$lang['18'] = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever ...";

$lang['19'] = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever ...";

$lang['20'] = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever ...";

$lang['21'] = "Site";

$lang['22'] = "Global Rank";

$lang['23'] = "PageRank";

$lang['24'] = "Web Safety";

$lang['25'] = "Primary Traffic";

$lang['26'] = "Server Location";

$lang['27'] = "HTTPS Test";

$lang['28'] = "Last Update";

$lang['29'] = "Go to Website";

$lang['30'] = "Update";

$lang['31'] = "Top Search Keywords";

$lang['32'] = "Visitors by Country";

$lang['34'] = "Server IP Address";

$lang['35'] = "HTTP Header";

$lang['36'] = "Domain Information - DNS Record";

$lang['37'] = "If you have any question, please contact us.";

$lang['38'] = "Please complete the short form below to send message to us. we will get back to you as soon as possible.";

$lang['39'] = "Can't send contact!";

$lang['40'] = "Send contact success!";

$lang['41'] = "Oops! Page Not Found";

$lang['42'] = "We're sorry, we couldn't locate the page you requested.";

$lang['43'] = "Tips";

$lang['44'] = "Check that the web address that you entered doesn't contain a typo.";

$lang['45'] = "Use the search box instead of your browser's address bar.";

$lang['46'] = "Go to the <a href='/'>homepage</a>.";

$lang['47'] = "Oops! Page Not Found";

$lang['48'] = "We're sorry, you site have been block by Administrator";

$lang['49'] = "Tips";

$lang['50'] = "Check that the web address that you entered doesn't contain a typo.";

$lang['51'] = "Use the search box instead of your browser's address bar.";

$lang['52'] = "Go to the <a href='/contact/'>Contact</a>.";

$lang['53'] = "Recently websites";

$lang['54'] = "Ads";

$lang['55'] = "Please enter your name.";

$lang['56'] = "Please enter a valid email address.";

$lang['57'] = "Please enter a valid email address.";

$lang['58'] = "You need to enter a subject.";

$lang['59'] = "You need to enter a message.";

$lang['60'] = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever ...";

$lang['61'] = "Analyzed with SeoStats Tools";

$lang['62'] = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever ...";

?>