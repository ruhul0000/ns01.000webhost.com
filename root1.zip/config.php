<?php
 
// Report all errors
error_reporting(E_ALL);

// Database Hostname
$dbHost = '';

// Database Username
$dbUser = '';

// Database Password
$dbPass = '';

// Domain Name
$dbName = '';

?>